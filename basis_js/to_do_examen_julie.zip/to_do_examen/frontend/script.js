const BASE_URL = "http://localhost:3000/todo";

function init() {
  clearList();
  fetch(BASE_URL)
    .then((res) => res.json())
    .then((res) => addToDos(res.todos));
}

function buildHTML() {
  const body = document.querySelector("body");
  //title
  const title = document.createElement("h1");
  title.innerText = "To Do";
  body.appendChild(title);
  //inputfield
  const inputForm = document.createElement("div");
  inputForm.setAttribute("id", "input-form");
  body.appendChild(inputForm);
  const inputField = document.createElement("input");
  inputField.setAttribute("id", "input-field");
  const submitButton = document.createElement("button");
  submitButton.innerText = "Submit";
  submitButton.setAttribute("onClick", "addNewToDo()");
  inputForm.appendChild(inputField);
  inputForm.appendChild(submitButton);
  //to do pending
  const pendingField = document.createElement("div");
  body.appendChild(pendingField);
  const pendingTitle = document.createElement("h2");
  pendingTitle.innerText = "To be done";
  pendingField.appendChild(pendingTitle);
  const pendingToDos = document.createElement("div");
  pendingToDos.setAttribute("id", "pending-field");
  pendingField.appendChild(pendingToDos);
  //to do done
  const doneField = document.createElement("div");
  body.appendChild(doneField);
  const doneTitle = document.createElement("h2");
  doneTitle.innerText = "Done";
  doneField.appendChild(doneTitle);
  const doneToDos = document.createElement("div");
  doneToDos.setAttribute("id", "done-field");
  doneField.appendChild(doneToDos);
}

function addToDos(data) {
  const pendingField = document.querySelector("#pending-field");
  const doneField = document.querySelector("#done-field");

  data.map((todo, i) => {
    if (todo.state === "in_progress") {
      const pendingItem = document.createElement("p");
      pendingField.appendChild(pendingItem);
      const pendingItemName = document.createElement("span");
      pendingItemName.innerText += todo.name;
      const checkBox = document.createElement("input");
      checkBox.setAttribute("type", "checkbox");
      checkBox.setAttribute("id", `${todo.name}_${todo.id.toString()}`);
      checkBox.setAttribute(
        "onClick",
        `changeCategory("${todo.name}", "${todo.id}")`
      );
      const crossMark = document.createElement("span");
      crossMark.setAttribute("class", "crossmark");
      crossMark.setAttribute("onClick", `deleteItem("${todo.id}")`);
      crossMark.innerText = "❌";
      pendingItem.appendChild(checkBox);
      pendingItem.appendChild(pendingItemName);
      pendingItem.appendChild(crossMark);
    } else {
      const doneItem = document.createElement("p");
      doneField.appendChild(doneItem);
      const doneItemName = document.createElement("span");
      doneItemName.innerText += todo.name;
      const checkBox = document.createElement("input");
      checkBox.setAttribute("type", "checkbox");
      checkBox.setAttribute("id", `${todo.name}_${todo.id.toString()}`);
      checkBox.setAttribute(
        "onClick",
        `changeCategory("${todo.name}", "${todo.id}")`
      );
      checkBox.checked = true;
      const crossMark = document.createElement("span");
      crossMark.setAttribute("class", "crossmark");
      crossMark.setAttribute("onClick", `deleteItem("${todo.id}")`);
      crossMark.innerText = "❌";
      doneItem.appendChild(checkBox);
      doneItem.appendChild(doneItemName);
      doneItem.appendChild(crossMark);
    }
  });
}

function addNewToDo() {
  const inputField = document.querySelector("#input-field");
  fetch(`${BASE_URL}/create`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: inputField.value,
      state: "in_progress",
    }),
  });
  inputField.value = "";
  init();
}

function clearList() {
  const pendingField = document.querySelector("#pending-field");
  const doneField = document.querySelector("#done-field");
  pendingField.innerHTML = "";
  doneField.innerHTML = "";
}

function deleteItem(id) {
  fetch(`${BASE_URL}/${id}`, {
    method: "DELETE",
  });
  init();
}

function changeCategory(name, id) {
  let checked = document.querySelector(`#${name}_${id.toString()}`).checked;

  if (checked) {
    fetch(`${BASE_URL}/update`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: id,
        state: "done",
      }),
    });
  } else {
    fetch(`${BASE_URL}/update`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: id,
        state: "in_progress",
      }),
    });
  }
  init();
}

// addNewToDo("other to do");
buildHTML();
init();
